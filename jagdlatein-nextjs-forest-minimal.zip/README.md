
# Jagdlatein – Next.js Starter (Minimal Forest Theme)

Upload like this:
1) Unzip
2) GitHub Repo `jagdlatein` → Add file → Upload files
3) Drag and drop everything
4) Commit changes → Vercel will deploy automatically
