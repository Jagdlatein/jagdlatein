
# Jagdlatein – Next.js Starter (erweitertes Layout)

**Upload am Handy (GitHub):**
1) ZIP herunterladen und entpacken.
2) GitHub Repo `jagdlatein` öffnen → **Add file → Upload files**.
3) Alle entpackten Dateien ins Feld ziehen → **Commit changes**.
4) Vercel: **New Project → Import GitHub Repo (jagdlatein) → Framework Next.js → Deploy**.

## Enthalten
- Startseite mit Header, Navigation, Hero, 3 Karten, Footer
- Farben: Grün **#1C2820**, Gold **#D4AF37**
- Platzhalter-Logo `/public/logo.png`
